function myinit()
	% addpath(genpath(pwd()));
	addpath('utils');
	addpath('basic_funcs');
	addpath('SRC');
	addpath('build_spams');
	addpath('ODL');
	myrng();
end
