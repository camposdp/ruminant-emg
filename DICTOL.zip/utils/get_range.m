function range  = get_range(a_range, c)
    range = a_range(c) + 1: a_range(c+1);
end 